$().ready(function () {
  alert("!");
});
