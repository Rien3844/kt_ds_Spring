package com.ktdsuniversity.edu.members.enums;

public enum ReadType {
	
	VIEW, UPDATE
}
