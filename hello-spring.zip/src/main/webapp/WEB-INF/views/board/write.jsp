<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <link rel="stylesheet" type="text/css" href="/css/hello-spring.css" />
    <title>게시글 작성</title>
  </head>
  <body>
    <h1>게시글 작성</h1>
    <form method="post" action="/write">
      <div class="grid write">
        <label for="subject">제목</label>
        <input
          id="subject"
          type="text"
          name="subject"
          placeholder="제목을 입력하세요."
        />

        <label for="email">이메일</label>
        <input
          id="email"
          type="email"
          name="email"
          placeholder="이메일을 입력하세요.
        "
        />

        <label for="content">내용</label>
        <textarea
          name="content"
          id="content"
          placeholder="내용을 입력하세요."
        ></textarea>

        <div class="btn-group">
          <div class="right-align">
            <input type="submit" value="저장" />
          </div>
        </div>
      </div>
    </form>
  </body>
</html>
